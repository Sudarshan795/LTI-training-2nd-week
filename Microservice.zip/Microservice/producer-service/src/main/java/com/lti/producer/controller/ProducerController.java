package com.lti.producer.controller;

import java.util.List;

import org.apache.juli.logging.Log;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.producer.entity.Producer;
import com.lti.producer.service.ProducerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/producer")
@Slf4j
public class ProducerController {

	private ProducerService producerService;

	@RequestMapping(value = "/service")
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public Producer getdetails() {

		Producer emp = new Producer();
		emp.setProducerId(500);
		emp.setName("Sudarshan");
		emp.setAge(26);
		emp.setTypeOfAccount("saving");

		if (emp.getName().equalsIgnoreCase("Sudarshan"))
			throw new RuntimeException();

		return emp;

	}

	public Producer getDataFallBack() {

		Producer emp = new Producer();
		emp.setProducerId(500);
		emp.setName("Sudarshan from fallback");
		emp.setAge(26);
		emp.setTypeOfAccount("saving-fallback");

		return emp;

	}

	@GetMapping("/getAll")
	private List<Producer> getAllProducer() {
		return producerService.getAllProducer();
	}

	@GetMapping("/producer/{id}") 
	private Producer getproducerById(@PathVariable("id") int id) {
		return producerService.getproducerById(id);
	}

	@DeleteMapping("/producer/{id}")
	private void deleteemployee(@PathVariable("id") int id) {
		producerService.delete(id);
	}

	@PostMapping("/producer")
	private ResponseEntity<Integer> saveproducer(@RequestBody Producer producer) {
		producerService.saveOrUpdate(producer);
		return new ResponseEntity(producer.getProducerId(), HttpStatus.OK);
	}

	@PutMapping("/producer")
	private String updateProducer(@RequestBody Producer producer) {

		Producer producer1 = new Producer();
		producer1.setName(producer1.getName());
		producer1.setAge(producer1.getAge());
		producerService.saveOrUpdate(producer1);
		return "Updated Successfully";
	}

}
