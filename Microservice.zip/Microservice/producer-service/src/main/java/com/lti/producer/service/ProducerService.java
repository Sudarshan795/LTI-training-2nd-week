package com.lti.producer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.producer.entity.Producer;
import com.lti.producer.repository.ProducerRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProducerService {

	@Autowired
	private ProducerRepository producerRepository;

	public List<Producer> getAllProducer() 
	{
	List<Producer> producer = new ArrayList<Producer>();
	producerRepository.findAll().forEach(e -> Producer.add(e));
	return producer;
	}
	public Producer getproducerById(int id) {
		
		return producerRepository.findById((long) id).get();
	}
	public void saveOrUpdate(Producer producer) 
	{
		producerRepository.save(producer);
	     
	}
	public void delete(int id) 
	{
		producerRepository.deleteById((long) id);
	}
	}