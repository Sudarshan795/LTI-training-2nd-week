package com.lti.consumer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.lti.consumer.VO.Producer;
import com.lti.consumer.VO.ResponseTemplateVO;
import com.lti.consumer.entity.Consumer;
import com.lti.consumer.repository.ConsumerRepsitory;

@Service
public class ConsumerService {

	@Autowired
	private ConsumerRepsitory consumerRepsitory;

	@Autowired
	private RestTemplate restTemplate;

	public ResponseTemplateVO getConsumerwithProducer(Long consumerId) {

		ResponseTemplateVO vo = new ResponseTemplateVO(null, null);
		Consumer consumer = consumerRepsitory.findByConsumerId(consumerId);
		
		Producer producer = restTemplate
				.getForObject("http://localhost:8081/producer/" + consumer.getConsumerId(), Producer.class);
		vo.setConsumer(consumer);
		vo.setProducer(producer);
		
		return vo;
	}

}
