package com.lti.consumer.VO;

import com.lti.consumer.entity.Consumer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseTemplateVO {
	
	private Consumer consumer;
	private Producer producer;
	
	public ResponseTemplateVO(Consumer consumer, Producer producer) {
		super();
		this.consumer = consumer;
		this.producer = producer;
	}
	public Consumer getConsumer() {
		return consumer;
	}
	public void setConsumer(Consumer consumer) {
		this.consumer = consumer;
	}
	public Producer getProducer() {
		return producer;
	}
	public void setProducer(Producer producer) {
		this.producer = producer;
	}
	@Override
	public String toString() {
		return "ResponseTemplateVO [consumer=" + consumer + ", producer=" + producer + "]";
	}
	
	
}
