package com.lti.consumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/consumer")
public class ConsumerController {

	@Autowired
	private LoadBalancerClient loadBalancer;

	@RequestMapping(value = "/Search", method = RequestMethod.GET)
	public String getConsumerFromProducer() {

		ServiceInstance serviceInstance = loadBalancer.choose("producer");
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/producer";
		System.out.println(baseUrl);
		RestTemplate restTemplate = new RestTemplate();
		String response = null;

		response = restTemplate.getForObject(baseUrl, String.class);

		System.out.println(" " + response);

		return response;

	}

	@RequestMapping(value = "/CircuitBreaker", method = RequestMethod.GET)
	public String getCircuitBreakerfService() {

		ServiceInstance serviceInstance = loadBalancer.choose("producer");
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/producer";
		System.out.println(baseUrl);
		RestTemplate restTemplate = new RestTemplate();
		String response = null;

		response = restTemplate.getForObject(baseUrl, String.class);

		System.out.println(" " + response);

		return response;

	}

}
