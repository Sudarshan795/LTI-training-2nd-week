package com.lti.consumer.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Consumer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long consumerId;
	private String ConsumerName;
	public Consumer(Long consumerId, String consumerName) {
		super();
		this.consumerId = consumerId;
		ConsumerName = consumerName;
	}
	public Long getConsumerId() {
		return consumerId;
	}
	public void setConsumerId(Long consumerId) {
		this.consumerId = consumerId;
	}
	public String getConsumerName() {
		return ConsumerName;
	}
	public void setConsumerName(String consumerName) {
		ConsumerName = consumerName;
	}
	@Override
	public String toString() {
		return "Consumer [consumerId=" + consumerId + ", ConsumerName=" + ConsumerName + "]";
	}

	
}
